*******
Authors
*******

Contributors (chronological)
============================

- Steven Loria `@sloria <https://github.com/sloria>`_
- Lucas Costa `@lucascosta <https://github.com/lucascosta>`_
- Jared Deckard `@deckar01 <https://github.com/deckar01>`_
- Matija Besednik `@matijabesednik <https://github.com/matijabesednik>`_
- Lucas Coutinho `@lucasrc <https://github.com/lucasrc>`_
- Douglas Anderson `@djanderson <https://github.com/djanderson>`_
- Yoichi NAKAYAMA `@yoichi <https://github.com/yoichi>`_
- Durmus U. Karatay `@ukaratay <https://github.com/ukaratay>`_
- Daisuke Taniwaki `@dtaniwaki <https://github.com/dtaniwaki>`_
- Felix Yan `@felixonmars <https://github.com/felixonmars>`_
- Jérôme Lafréchoux `@lafrech <https://github.com/lafrech>`_
- Marcin Lulek `@ergo <https://github.com/ergo>`_
- Aaron Ramshaw `@ramshaw888 <https://github.com/ramshaw888>`_
- PelleK `@elfjes <https://github.com/elfjes>`_
